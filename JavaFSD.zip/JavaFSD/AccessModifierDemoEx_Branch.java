package JavaFSD;

public class AccessModifierDemoEx_Branch {
	 
    public static void main(String[] args) {
    	
    	AccessModifierDemoEx_Bank bank = new AccessModifierDemoEx_Bank("ABC Bank", 10000000, 5000, "John Smith");
        bank.displayBankDetails();

        AccessModifierDemoEx_Customer customer1 = new AccessModifierDemoEx_Customer("Alice khanna", 25, "123 Main St.", "Checking", 1001, 5000);
        customer1.displayCustomerDetails();

        AccessModifierDemoEx_Customer customer2 = new AccessModifierDemoEx_Customer("Bob reddy", 30, "456 Oak St.", "Savings", 1002, 10000);
        customer2.displayCustomerDetails();

        // Trying to access private member variable of Customer outside its class
        // customer1.name = "Alice Doe";  // Not allowed

        // Trying to access protected member variable of Customer outside its package
        // customer1.balance = 15000;  // Not allowed

        // Trying to access default member variable of Bank outside its package
        // bank.totalAccounts = 6000;  // Not allowed

        // Accessing public member variable of Bank outside its class and package
        bank.managerName = "Jake Tiwari";

        // Trying to access protected method of Customer outside its package
        // customer1.setAddress("789 Pine St.");  // Not allowed

        // Accessing public method of Customer outside its class and package
        customer1.deposit(1000);
        customer1.displayCustomerDetails();

        // Accessing public method of Customer outside its class and package
        customer2.withdraw(500);
        customer2.displayCustomerDetails();
    }
}
