package JavaFSD;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionDemo {
    public static void main(String[] args) {
        String text = "Contact us at info@example.com or support@example.org for assistance.";

        // Define the regular expression to match email addresses
        Pattern pattern = Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b");

        // Match the regular expression against the text
        Matcher matcher = pattern.matcher(text);

        // Print all matched email addresses
        while (matcher.find()) {
            System.out.println("Matched email address: " + matcher.group());
        }
    }
}
