package JavaFSD;

public class ConstructorDemo_Hospital {
    private String name;
    private int capacity;
    
    // Default constructor
    public ConstructorDemo_Hospital() {
        this.name = "Default Hospital";
        this.capacity = 100;
    }
    
    // Parameterized constructor
    public ConstructorDemo_Hospital(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
    }
    
    // Copy constructor
    public ConstructorDemo_Hospital(ConstructorDemo_Hospital hospital) {
        this.name = hospital.name;
        this.capacity = hospital.capacity;
    }
    
    public String getName() {
        return this.name;
    }
    
    public int getCapacity() {
        return this.capacity;
    }
    
    public static class Doctor {
        private String name;
        private int age;
        
        // Default constructor
        public Doctor() {
            this.name = "Default Doctor";
            this.age = 30;
        }
        
        // Parameterized constructor
        public Doctor(String name, int age) {
            this.name = name;
            this.age = age;
        }
        
        // Copy constructor
        public Doctor(Doctor doctor) {
            this.name = doctor.name;
            this.age = doctor.age;
        }
        
        public String getName() {
            return this.name;
        }
        
        public int getAge() {
            return this.age;
        }
    }
    
    public static void main(String[] args) {
        // Using the default constructor of Hospital class
        ConstructorDemo_Hospital defaultHospital = new ConstructorDemo_Hospital();
        System.out.println("Name of default hospital: " + defaultHospital.getName());
        System.out.println("Capacity of default hospital: " + defaultHospital.getCapacity());
        
        // Using the parameterized constructor of Hospital class
        ConstructorDemo_Hospital hospital1 = new ConstructorDemo_Hospital("Hospital 1", 200);
        System.out.println("Name of hospital 1: " + hospital1.getName());
        System.out.println("Capacity of hospital 1: " + hospital1.getCapacity());
        
        // Using the copy constructor of Hospital class
        ConstructorDemo_Hospital hospital2 = new ConstructorDemo_Hospital(hospital1);
        System.out.println("Name of hospital 2: " + hospital2.getName());
        System.out.println("Capacity of hospital 2: " + hospital2.getCapacity());
        
        // Using the default constructor of Doctor class
        Doctor defaultDoctor = new ConstructorDemo_Hospital.Doctor();
        System.out.println("Name of default doctor: " + defaultDoctor.getName());
        System.out.println("Age of default doctor: " + defaultDoctor.getAge());
        
        // Using the parameterized constructor of Doctor class
        Doctor doctor1 = new ConstructorDemo_Hospital.Doctor("Doctor 1", 35);
        System.out.println("Name of doctor 1: " + doctor1.getName());
        System.out.println("Age of doctor 1: " + doctor1.getAge());
        
        // Using the copy constructor of Doctor class
        Doctor doctor2 = new ConstructorDemo_Hospital.Doctor(doctor1);
        System.out.println("Name of doctor 2: " + doctor2.getName());
        System.out.println("Age of doctor 2: " + doctor2.getAge());
    }
}
