package JavaFSD;

import java.util.Scanner;

public class ArithmeticCalculator {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the numbers separated by space:");
        String input = scanner.nextLine();

        // Split the input string into an array of numbers
        String[] numbers = input.split(" ");
        double[] operands = new double[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            operands[i] = Double.parseDouble(numbers[i]);
        }

        System.out.println("Enter the operation (+, -, *, /):");
        char operation = scanner.next().charAt(0);

        double result;
        switch (operation) {
            case '+':
                result = operands[0];
                for (int i = 1; i < operands.length; i++) {
                    result += operands[i];
                }
                break;
            case '-':
                result = operands[0];
                for (int i = 1; i < operands.length; i++) {
                    result -= operands[i];
                }
                break;
            case '*':
                result = operands[0];
                for (int i = 1; i < operands.length; i++) {
                    result *= operands[i];
                }
                break;
            case '/':
                result = operands[0];
                for (int i = 1; i < operands.length; i++) {
                    result /= operands[i];
                }
                break;
            default:
                System.out.println("Invalid operation!");
                return;
        }

        System.out.print("Result: " + result);
       
    }
}
