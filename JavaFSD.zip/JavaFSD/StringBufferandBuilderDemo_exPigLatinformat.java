package JavaFSD;



public class StringBufferandBuilderDemo_exPigLatinformat {
    public static void main(String[] args) {
        String originalString = "The quick brown fox jumps over the lazy dog.";
        System.out.println("Original String: " + originalString);

        // Converting string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);
        stringBuffer.reverse();
        System.out.println("StringBuffer: " + stringBuffer);

        // Converting string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);
        stringBuilder.delete(4, 9);
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
