package JavaFSD;

//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//import javax.swing.JOptionPane;

//public class EmailValidator {
//
//    public static void main(String[] args) {
//        
//        String pattern = "^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\\.([a-z][a-z|0-9]*(\\.[a-z][a-z|0-9]*)?)$";
//        Pattern regexPattern = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);
//
//        String email = JOptionPane.showInputDialog("Enter your email address:");
//        Matcher matcher = regexPattern.matcher(email.trim());
//
//        if (matcher.matches()) {
//            JOptionPane.showMessageDialog(null, "Valid email address.");
//        } else {
//            JOptionPane.showMessageDialog(null, "Invalid email address.");
//        }
//    }
//}





 
/**import java.util.Scanner;
 * 
 * public class EmailValidator {
 
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter an email address: ");
        String email = sc.nextLine();

        boolean isValid = validateEmail(email);

        if (isValid) {
            System.out.println(email + " is a valid email address.");
        } else {
            System.out.println(email + " is an invalid email address.");
        }
    }

    public static boolean validateEmail(String email) {
        
        // Check if email has exactly one @ symbol
        int atSymbolCount = 0;
        for (int i = 0; i < email.length(); i++) {
            if (email.charAt(i) == '@') {
                atSymbolCount++;
            }
        }
        if (atSymbolCount != 1) {
            return false;
        }

        // Check if email starts with a letter
        if (!Character.isLetter(email.charAt(0))) {
            return false;
        }

        // Check if email ends with a letter or a number
        char lastChar = email.charAt(email.length() - 1);
        if (!Character.isLetter(lastChar) && !Character.isDigit(lastChar)) {
            return false;
        }

        // Check if email contains only letters, numbers, dot (.), underscore (_), and @ symbol
        for (int i = 0; i < email.length(); i++) {
            char c = email.charAt(i);
            if (!Character.isLetter(c) && !Character.isDigit(c) && c != '.' && c != '_' && c != '@') {
                return false;
            }
        }

        return true;
    }
}

* @author Acer
*
*/
import java.util.Scanner;

public class EmailValidator {

    public static void main(String[] args) {

        // Initialize an array of strings
        String[] words = {"apple", "banana", "cherry", "date", "elderberry"};

        // Ask the user for a string to search for
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string to search for: ");
        String searchStr = scanner.nextLine();

        // Search for the string in the array
        boolean found = false;
        for (String word : words) {
            if (word.equals(searchStr)) {
                found = true;
                break;
            }
        }

        // Display the search result
        if (found) {
            System.out.println("The string \"" + searchStr + "\" was found in the array.");
        } else {
            System.out.println("The string \"" + searchStr + "\" was not found in the array.");
        }
    }
}
