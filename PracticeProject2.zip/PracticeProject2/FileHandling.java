package PracticeProject2;

import java.io.*;
import java.util.Scanner;

public class FileHandling {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to File Operations!");
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine();

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Read from file");
            System.out.println("2. Write to file");
            System.out.println("3. Append to file");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    readFile(fileName);
                    break;
                case 2:
                    System.out.print("Enter the content to write: ");
                    String contentToWrite = scanner.nextLine();
                    writeFile(fileName, contentToWrite);
                    break;
                case 3:
                    System.out.print("Enter the content to append: ");
                    String contentToAppend = scanner.nextLine();
                    appendToFile(fileName, contentToAppend);
                    break;
                case 4:
                    System.out.println("Exiting the program...");
                    scanner.close();
                    System.exit(0);
                    closeEclipse();
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void closeEclipse() {
		
    	 try {
             String os = System.getProperty("os.name").toLowerCase();
             if (os.contains("win")) {
                 Runtime.getRuntime().exec("taskkill /f /im eclipse.exe");
             } else if (os.contains("mac") || os.contains("nix") || os.contains("nux") || os.contains("sunos")) {
                 Runtime.getRuntime().exec("pkill eclipse");
             }
         } 
         catch (IOException e) {
             System.out.println("An error occurred while trying to close Eclipse: " + e.getMessage());
         }
		
	}

	public static void readFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            System.out.println("\nContent of the file:");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }

    public static void writeFile(String fileName, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(content);
            System.out.println("Content successfully written to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }

    public static void appendToFile(String fileName, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(content);
            System.out.println("Content successfully appended to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while appending to the file: " + e.getMessage());
        }
    }

}
