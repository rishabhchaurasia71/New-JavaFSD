package PracticeProject1;

import java.util.LinkedList;
import java.util.Queue;

public class ThreadSleepandWaitDemo {
    private static final Object lock = new Object();
    private static final int MAX_CAPACITY = 5;
    private static final Queue<String> passengersQueue = new LinkedList<>();

    public static void main(String[] args) {
        Thread ticketBookingThread = new Thread(new TicketBooking());
        Thread passengerBoardingThread = new Thread(new PassengerBoarding());

        ticketBookingThread.start();
        passengerBoardingThread.start();
    }

    static class TicketBooking implements Runnable {
        @Override
        public void run() {
            synchronized (lock) {
                try {
                    for (int i = 1; i <= 10; i++) {
                        while (passengersQueue.size() == MAX_CAPACITY) {
                            System.out.println("Ticket Booking: Waiting for passengers to board...");
                            lock.wait();
                        }
                        String passenger = "Passenger " + i;
                        passengersQueue.add(passenger);
                        System.out.println("Ticket Booking: Booked ticket for " + passenger);
                        Thread.sleep(1000); // Simulating ticket booking process
                        lock.notify(); // Notify the passenger boarding thread
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    static class PassengerBoarding implements Runnable {
        @Override
        public void run() {
            synchronized (lock) {
                try {
                    while (true) {
                        while (passengersQueue.isEmpty()) {
                            System.out.println("Passenger Boarding: No passengers available...");
                            lock.wait();
                        }
                        String passenger = passengersQueue.poll();
                        System.out.println("Passenger Boarding: Passenger " + passenger + " boarded the train");
                        Thread.sleep(2000); // Simulating boarding process
                        lock.notify(); // Notify the ticket booking thread
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
